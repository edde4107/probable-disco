Meeting Minutes
* make sure you have at least 1 commit in release notes
* Plan is very important to make: each person is shown with what they need to do
* access token should be stored in user's session, never in global
* what should be in .env file should be in the readme