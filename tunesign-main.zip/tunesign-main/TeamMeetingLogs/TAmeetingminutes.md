4-1-2024
have more posted in GitHub, updated project board, release notes etc. prepared more thoroughly before each meeting
focus on developing functionality and getting to a working state as soon as possible, it doesn't matter if it isn't perfect

by the end of this week, we should have:
- have a functioning, testable website that can be interacted with to some degree (does not need to be 100% finished, just have something to build on quicker)
- implement basic database initialization and test (insert, read from, etc.)
- begin testing login functionality (we want to have this finished ASAP, sometime next week at the latest)