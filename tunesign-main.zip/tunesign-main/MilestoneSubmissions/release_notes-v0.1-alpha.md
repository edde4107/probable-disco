## What's Changed
* Jasper/login page UI by @jash3852 in https://github.com/ashleycody345/tunesign/pull/14
* Lachlan created the docker-compose and the package files needed to run the docker server including package.json and package-lock.json

## New Contributors
* @jash3852 made their first contribution in https://github.com/ashleycody345/tunesign/pull/14

**Full Changelog**: https://github.com/ashleycody345/tunesign/commits/v0.1-alpha
