
## What's Changed
* Jasper tunesign register and login by @jash3852 in https://github.com/ashleycody345/tunesign/pull/27
* Created homeNotLinkedToSpotify by @edde4107 in https://github.com/ashleycody345/tunesign/pull/32
* Lab11part c by @jash3852 in https://github.com/ashleycody345/tunesign/pull/33
* Merge new queries with updated database information by @ashleycody345 in https://github.com/ashleycody345/tunesign/pull/34
* Connect login with spotify page to other parts by @jash3852 in https://github.com/ashleycody345/tunesign/pull/35
* I'm just using the pull request to document this spread sheet that I made that helped Ashley create the database by @Lachlankotarski in https://github.com/ashleycody345/tunesign/pull/36
* Export Page Element and Export Functionality (statically) by @Lachlankotarski in https://github.com/ashleycody345/tunesign/pull/38
* Fixed Navbar and Redirects by @edde4107 in https://github.com/ashleycody345/tunesign/pull/40
* Ashley queryfunctions by @ashleycody345 in https://github.com/ashleycody345/tunesign/pull/43
* About page and export functionality edit by @Lachlankotarski in https://github.com/ashleycody345/tunesign/pull/41
* Ben pulling data by @BenAntonious in https://github.com/ashleycody345/tunesign/pull/44
* Jasper assign zodiac by @jash3852 in https://github.com/ashleycody345/tunesign/pull/46


**Full Changelog**: https://github.com/ashleycody345/tunesign/compare/v0.2alpha...v0.3.1-alpha

Implemented Spotify API interaction, created functions to handle user data parsing and assignments, and expanded database interactions through website.